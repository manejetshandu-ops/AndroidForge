plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.tendollar.aurexcollector"
    compileSdk = 35

    // Use Java 17 bytecode and language compatibility.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // Keep Kotlin bytecode aligned with Java 17.
    kotlinOptions {
        jvmTarget = "17"
    }
    defaultConfig {
        applicationId = "com.tendollar.aurexcollector"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
