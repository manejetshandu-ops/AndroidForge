package com.tendollar.aurexcollector

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private lateinit var status: TextView
    private val createFileRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
        }
        layout.addView(TextView(this).apply {
            text = "AUREX WhatsApp Message Collector"
            textSize = 24f
        })
        layout.addView(TextView(this).apply {
            text = "Collects only message text Android exposes in WhatsApp notifications. It cannot read messages hidden by WhatsApp or recover complete group history."
            textSize = 16f
            setPadding(0, 20, 0, 20)
        })
        status = TextView(this).apply { textSize = 16f; setPadding(0, 8, 0, 20) }
        layout.addView(status)
        layout.addView(Button(this).apply {
            text = "Enable notification access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "Export TXT log"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TITLE, "aurex_whatsapp_messages.txt")
                }
                startActivityForResult(intent, createFileRequest)
            }
        })
        layout.addView(Button(this).apply {
            text = "Refresh status"
            setOnClickListener { updateStatus() }
        })
        setContentView(layout)
        updateStatus()
    }

    private fun updateStatus() {
        val file = File(filesDir, "messages.txt")
        status.text = "Saved locally: ${file.length()} bytes\nLog file: app-private storage\nNotification access: grant it in Android Settings."
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == createFileRequest && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                val source = File(filesDir, "messages.txt")
                contentResolver.openOutputStream(uri)?.use { out ->
                    if (source.exists()) source.inputStream().use { it.copyTo(out) }
                }
                Toast.makeText(this, "TXT export complete", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
