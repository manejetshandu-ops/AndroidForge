package com.tendollar.aurexcollector

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class WhatsAppNotificationListener : NotificationListenerService() {
    private val acceptedPackages = setOf("com.whatsapp", "com.whatsapp.w4b")
    private val seen = object : LinkedHashMap<String, Boolean>(400, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Boolean>?): Boolean = size > 400
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName !in acceptedPackages) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()
            ?.takeIf { it.isNotEmpty() }
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        if (text.isBlank() || text == "1 new message" || text == "You may have new messages") return
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
            ?.mapNotNull { it?.toString()?.trim()?.takeIf(String::isNotEmpty) }
        val body = if (!lines.isNullOrEmpty()) lines.joinToString(" | ") else text
        val stamp = sbn.postTime
        val key = "${sbn.key}|$stamp|$title|$body"
        synchronized(seen) {
            if (seen.containsKey(key)) return
            seen[key] = true
        }
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(stamp))
        val safeTitle = title.replace("\n", " ").replace("\r", " ")
        val safeBody = body.replace("\r", " ").replace("\n", " ")
        val entry = "$time\t$safeTitle\t$safeBody\n"
        try {
            File(filesDir, "messages.txt").appendText(entry, Charsets.UTF_8)
        } catch (_: Exception) {
            // Keep listener alive if storage is temporarily unavailable.
        }
    }
}
