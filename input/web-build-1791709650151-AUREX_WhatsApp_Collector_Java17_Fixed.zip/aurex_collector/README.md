# AUREX WhatsApp Message Collector

Android source project for a local notification-based TXT collector. It only records WhatsApp notification text Android exposes; it does not read WhatsApp private storage or guarantee full group capture.

## Java / Gradle versions
- Java (JDK): 17
- Gradle: 8.9
- Android Gradle Plugin: 8.7.3

The app's Java and Kotlin compilation targets are both explicitly set to JVM 17.

## Build APK using GitHub Actions
1. Create a GitHub repository and upload the contents of this folder to the repository root.
2. Open the repository's **Actions** tab and run **Build AUREX APK** (or push to `main`).
3. When the workflow completes, open its run and download the artifact named `AUREX-WhatsApp-Collector-debug-apk`.
4. Extract `app-debug.apk` and install it on your Android phone. Android may ask you to allow installation from that source.
5. Open the app, tap **Enable notification access**, and enable AUREX Message Collector in Android Settings.
6. To export, open the app and tap **Export TXT log**.

The log is stored in app-private storage. Android may stop background work or suppress message previews; messages that are hidden, grouped, truncated, or never surfaced as notifications will not be captured. The app is an unsigned debug build, suitable for personal testing, not Play Store release.
